
"use strict";

require("dotenv").config();

const express = require("express");
const cors = require("cors");

const app = express();

const PORT = Number(process.env.PORT) || 3000;

app.disable("x-powered-by");

app.use(cors({
  origin: process.env.ALLOWED_ORIGIN
    ? process.env.ALLOWED_ORIGIN.split(",").map(s => s.trim())
    : true,
  methods: ["GET", "POST", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Authorization"]
}));

app.use(express.json({
  limit: "25mb"
}));

app.use(express.urlencoded({
  extended: false,
  limit: "1mb"
}));

// Check which AI providers have API keys configured.
function getConfiguredProviders() {
  const providers = {
    gemini: "GEMINI_API_KEY",
    mistral: "MISTRAL_API_KEY",
    openrouter: "OPENROUTER_API_KEY",
    groq: "GROQ_API_KEY",
    cerebras: "CEREBRAS_API_KEY",
    together: "TOGETHER_API_KEY",
    cohere: "COHERE_API_KEY",
    fireworks: "FIREWORKS_API_KEY"
  };

  return Object.entries(providers)
    .filter(([, key]) => Boolean(process.env[key]))
    .map(([name]) => name);
}

// Basic welcome route.
app.get("/", (req, res) => {
  res.json({
    success: true,
    name: "A² Builder Backend",
    message: "Backend is running.",
    version: "1.0.0"
  });
});

// Health check.
app.get("/api/health", (req, res) => {
  res.json({
    success: true,
    status: "healthy",
    service: "A² Builder Backend",
    version: "1.0.0",
    configuredAIProviders: getConfiguredProviders(),
    configuredAIProviderCount: getConfiguredProviders().length,
    timestamp: new Date().toISOString()
  });
});

// Provider configuration status.
app.get("/api/providers", (req, res) => {
  const configured = getConfiguredProviders();

  res.json({
    success: true,
    providers: [
      "gemini",
      "mistral",
      "openrouter",
      "groq",
      "cerebras",
      "together",
      "cohere",
      "fireworks"
    ].map(name => ({
      name,
      configured: configured.includes(name)
    }))
  });
});

console.log("A² Builder backend foundation loaded.");

/* =========================================
   BATCH 4 — A² BUILDER AI ENGINE
========================================= */

const AI_SYSTEM_PROMPT = `
You are the AI coding assistant for A² Builder.

Help users build, debug, explain, and improve websites,
web applications, and backend APIs.

Rules:
- Follow the user's instructions carefully.
- Preserve existing features when modifying code.
- Generate complete, practical code when requested.
- Use HTML, CSS, and JavaScript appropriately.
- Never expose API keys or secret credentials.
- Never claim code has been deployed or executed unless
  that operation actually happened.
- Explain errors clearly and suggest useful fixes.
`;

function getErrorMessage(error) {
  return String(error?.message || error || "Unknown error");
}

const AI_PROVIDERS = {
  gemini: {
    key: "GEMINI_API_KEY",
    model: "gemini-2.5-flash",
    url: "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent",
    type: "gemini"
  },

  mistral: {
    key: "MISTRAL_API_KEY",
    model: "mistral-small-latest",
    url: "https://api.mistral.ai/v1/chat/completions"
  },

  openrouter: {
    key: "OPENROUTER_API_KEY",
    model: "google/gemini-2.5-flash",
    url: "https://openrouter.ai/api/v1/chat/completions"
  },

  groq: {
    key: "GROQ_API_KEY",
    model: "llama-3.3-70b-versatile",
    url: "https://api.groq.com/openai/v1/chat/completions"
  },

  cerebras: {
    key: "CEREBRAS_API_KEY",
    model: "llama-3.3-70b",
    url: "https://api.cerebras.ai/v1/chat/completions"
  },

  together: {
    key: "TOGETHER_API_KEY",
    model: "meta-llama/Llama-3.3-70B-Instruct-Turbo",
    url: "https://api.together.xyz/v1/chat/completions"
  },

  cohere: {
    key: "COHERE_API_KEY",
    model: "command-a-03-2025",
    url: "https://api.cohere.com/v2/chat",
    type: "cohere"
  },

  fireworks: {
    key: "FIREWORKS_API_KEY",
    model: "accounts/fireworks/models/llama-v3p3-70b-instruct",
    url: "https://api.fireworks.ai/inference/v1/chat/completions"
  }
};

const AI_PROVIDER_ORDER = [
  "gemini",
  "groq",
  "cerebras",
  "mistral",
  "openrouter",
  "together",
  "cohere",
  "fireworks"
];

async function requestProvider(providerName, prompt, systemPrompt) {
  const config = AI_PROVIDERS[providerName];

  if (!config) {
    throw new Error("Unknown AI provider: " + providerName);
  }

  const apiKey = process.env[config.key];

  if (!apiKey) {
    throw new Error(providerName + " API key is not configured.");
  }

  let response;
  let body;

  if (config.type === "gemini") {
    response = await fetch(
      config.url + "?key=" + encodeURIComponent(apiKey),
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          system_instruction: {
            parts: [{ text: systemPrompt }]
          },
          contents: [{
            role: "user",
            parts: [{ text: prompt }]
          }],
          generationConfig: {
            temperature: 0.4,
            maxOutputTokens: 8192
          }
        }),
        signal: AbortSignal.timeout(60000)
      }
    );
  } else if (config.type === "cohere") {
    response = await fetch(config.url, {
      method: "POST",
      headers: {
        "Authorization": "Bearer " + apiKey,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: config.model,
        stream: false,
        messages: [
          {
            role: "system",
            content: systemPrompt
          },
          {
            role: "user",
            content: prompt
          }
        ]
      }),
      signal: AbortSignal.timeout(60000)
    });
  } else {
    response = await fetch(config.url, {
      method: "POST",
      headers: {
        "Authorization": "Bearer " + apiKey,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: config.model,
        messages: [
          {
            role: "system",
            content: systemPrompt
          },
          {
            role: "user",
            content: prompt
          }
        ],
        temperature: 0.4,
        max_tokens: 8192
      }),
      signal: AbortSignal.timeout(60000)
    });
  }

  body = await response.json().catch(() => ({}));

  if (!response.ok) {
    const providerError =
      body?.error?.message ||
      body?.message ||
      body?.detail ||
      ("HTTP " + response.status);

    throw new Error(
      providerName + " request failed: " + providerError
    );
  }

  let answer = "";

  if (config.type === "gemini") {
    answer = (body.candidates?.[0]?.content?.parts || [])
      .map(part => part.text || "")
      .join("\n");
  } else if (config.type === "cohere") {
    answer = (body.message?.content || [])
      .filter(item => item.type === "text")
      .map(item => item.text || "")
      .join("\n");
  } else {
    answer = body.choices?.[0]?.message?.content || "";
  }

  if (!answer.trim()) {
    throw new Error(providerName + " returned an empty response.");
  }

  return answer.trim();
}

async function generateWithAI(options = {}) {
  const prompt = String(options.prompt || "").trim();

  if (!prompt) {
    throw new Error("Please enter a prompt.");
  }

  if (prompt.length > 30000) {
    throw new Error("Your prompt is too long. Maximum: 30,000 characters.");
  }

  const requestedProvider = String(options.provider || "auto")
    .toLowerCase();

  const systemPrompt = String(
    options.systemPrompt || AI_SYSTEM_PROMPT
  );

  let providers;

  if (requestedProvider === "auto") {
    providers = AI_PROVIDER_ORDER.filter(name =>
      Boolean(process.env[AI_PROVIDERS[name].key])
    );
  } else {
    if (!AI_PROVIDERS[requestedProvider]) {
      throw new Error("Unsupported AI provider.");
    }

    providers = [requestedProvider];
  }

  if (!providers.length) {
    throw new Error(
      "No AI providers are configured. Add at least one API key in your hosting environment."
    );
  }

  const errors = [];

  for (const providerName of providers) {
    try {
      const answer = await requestProvider(
        providerName,
        prompt,
        systemPrompt
      );

      return {
        answer,
        provider: providerName,
        fallback: errors.length > 0,
        errors
      };
    } catch (error) {
      const message = getErrorMessage(error);

      console.error(
        "AI provider " + providerName + " failed:",
        message
      );

      errors.push({
        provider: providerName,
        message
      });

      // Explicit provider selection does not silently switch providers.
      if (requestedProvider !== "auto") {
        break;
      }
    }
  }

  const failure = new Error(
    "All available AI providers failed. Check your API keys, provider model access, and usage limits."
  );

  failure.providerErrors = errors;
  throw failure;
}

// General AI endpoint.
app.post("/api/ai", async (req, res) => {
  try {
    const result = await generateWithAI({
      prompt: req.body?.prompt,
      provider: req.body?.provider || "auto",
      systemPrompt: req.body?.systemPrompt || AI_SYSTEM_PROMPT
    });

    res.json({
      success: true,
      response: result.answer,
      answer: result.answer,
      message: result.answer,
      provider: result.provider,
      fallback: result.fallback,
      errors: result.errors
    });
  } catch (error) {
    res.status(502).json({
      success: false,
      error: getErrorMessage(error),
      providerErrors: error.providerErrors || []
    });
  }
});

// Website and application generation endpoint.
app.post("/api/generate", async (req, res) => {
  try {
    const prompt = String(req.body?.prompt || "").trim();

    const projectContext = req.body?.project
      ? "\n\nProject context:\n" +
        (typeof req.body.project === "string"
          ? req.body.project
          : JSON.stringify(req.body.project).slice(0, 10000))
      : "";

    const result = await generateWithAI({
      prompt: prompt + projectContext,
      provider: req.body?.provider || "auto",
      systemPrompt: AI_SYSTEM_PROMPT
    });

    res.json({
      success: true,
      response: result.answer,
      answer: result.answer,
      message: result.answer,
      provider: result.provider,
      fallback: result.fallback,
      errors: result.errors
    });
  } catch (error) {
    res.status(502).json({
      success: false,
      error: getErrorMessage(error),
      providerErrors: error.providerErrors || []
    });
  }
});
  
/* =========================================
   BATCH 5 — MEDIA & WEBSITE IMPORT
========================================= */

const dns = require("node:dns").promises;
const net = require("node:net");

const PEXELS_API = "https://api.pexels.com";

function isPrivateAddress(ip) {
  if (net.isIPv4(ip)) {
    const p = ip.split(".").map(Number);

    return (
      p[0] === 0 ||
      p[0] === 10 ||
      p[0] === 127 ||
      p[0] >= 224 ||
      (p[0] === 169 && p[1] === 254) ||
      (p[0] === 172 && p[1] >= 16 && p[1] <= 31) ||
      (p[0] === 192 && p[1] === 168) ||
      (p[0] === 100 && p[1] >= 64 && p[1] <= 127)
    );
  }

  if (net.isIPv6(ip)) {
    const value = ip.toLowerCase();

    return (
      value === "::" ||
      value === "::1" ||
      value.startsWith("fc") ||
      value.startsWith("fd") ||
      /^fe[89ab]/.test(value) ||
      value.startsWith("::ffff:") ||
      value.startsWith("2001:db8:")
    );
  }

  return true;
}

async function validateExternalUrl(value) {
  let url;

  try {
    url = new URL(value);
  } catch {
    throw new Error("Please provide a valid website URL.");
  }

  if (url.protocol !== "https:") {
    throw new Error("Only HTTPS website URLs are accepted.");
  }

  if (url.username || url.password) {
    throw new Error("URLs containing credentials are not accepted.");
  }

  const hostname = url.hostname.toLowerCase();

  if (
    hostname === "localhost" ||
    hostname.endsWith(".localhost") ||
    hostname.endsWith(".local") ||
    hostname.endsWith(".internal")
  ) {
    throw new Error("This hostname is not permitted.");
  }

  if (net.isIP(hostname)) {
    if (isPrivateAddress(hostname)) {
      throw new Error("Private network addresses are not permitted.");
    }
  } else {
    let addresses;

    try {
      addresses = await dns.lookup(hostname, { all: true });
    } catch {
      throw new Error("The website hostname could not be resolved.");
    }

    if (
      !addresses.length ||
      addresses.some(item => isPrivateAddress(item.address))
    ) {
      throw new Error("This website resolves to a restricted address.");
    }
  }

  return url;
}

async function fetchExternalWebsite(value) {
  let url = await validateExternalUrl(value);

  for (let attempt = 0; attempt < 4; attempt++) {
    const response = await fetch(url, {
      method: "GET",
      redirect: "manual",
      headers: {
        "User-Agent": "A2Builder-WebsiteImporter/1.0",
        "Accept": "text/html,application/xhtml+xml"
      },
      signal: AbortSignal.timeout(15000)
    });

    if ([301, 302, 303, 307, 308].includes(response.status)) {
      const location = response.headers.get("location");

      if (!location) {
        throw new Error("Website redirect has no destination.");
      }

      url = await validateExternalUrl(
        new URL(location, url).toString()
      );

      continue;
    }

    if (!response.ok) {
      throw new Error("Website returned HTTP " + response.status + ".");
    }

    const contentType = response.headers.get("content-type") || "";

    if (!contentType.toLowerCase().includes("text/html")) {
      throw new Error("The supplied URL did not return an HTML page.");
    }

    const declaredLength = Number(
      response.headers.get("content-length") || 0
    );

    if (declaredLength > 1024 * 1024) {
      throw new Error("Website HTML exceeds the 1 MB import limit.");
    }

    const reader = response.body.getReader();
    const chunks = [];
    let total = 0;

    try {
      while (true) {
        const { done, value: chunk } = await reader.read();

        if (done) break;

        total += chunk.byteLength;

        if (total > 1024 * 1024) {
          await reader.cancel();
          throw new Error("Website HTML exceeds the 1 MB import limit.");
        }

        chunks.push(Buffer.from(chunk));
      }
    } finally {
      reader.releaseLock();
    }

    return {
      url: url.toString(),
      html: Buffer.concat(chunks).toString("utf8")
    };
  }

  throw new Error("Too many website redirects.");
}

// Pexels configuration status.
app.get("/api/media/status", (req, res) => {
  res.json({
    success: true,
    provider: "Pexels",
    configured: Boolean(process.env.PEXELS_API_KEY),
    photosEndpoint: "/api/pexels/photos",
    videosEndpoint: "/api/pexels/videos"
  });
});

// Search Pexels photos.
app.get("/api/pexels/photos", async (req, res) => {
  try {
    const apiKey = process.env.PEXELS_API_KEY;

    if (!apiKey) {
      return res.status(503).json({
        success: false,
        error: "Pexels API key is not configured."
      });
    }

    const query = String(req.query.q || "").trim();

    if (!query) {
      return res.status(400).json({
        success: false,
        error: "Provide a search term using ?q=."
      });
    }

    const params = new URLSearchParams({
      query: query.slice(0, 200),
      per_page: String(
        Math.min(30, Math.max(1, Number(req.query.per_page) || 12))
      )
    });

    const response = await fetch(
      PEXELS_API + "/v1/search?" + params.toString(),
      {
        headers: { Authorization: apiKey },
        signal: AbortSignal.timeout(20000)
      }
    );

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      return res.status(502).json({
        success: false,
        error: "Pexels photo search failed.",
        details: data.error || data.message || response.status
      });
    }

    res.json({
      success: true,
      total_results: data.total_results || 0,
      photos: data.photos || []
    });
  } catch (error) {
    res.status(502).json({
      success: false,
      error: getErrorMessage(error)
    });
  }
});

// Search Pexels videos.
app.get("/api/pexels/videos", async (req, res) => {
  try {
    const apiKey = process.env.PEXELS_API_KEY;

    if (!apiKey) {
      return res.status(503).json({
        success: false,
        error: "Pexels API key is not configured."
      });
    }

    const query = String(req.query.q || "").trim();

    if (!query) {
      return res.status(400).json({
        success: false,
        error: "Provide a search term using ?q=."
      });
    }

    const params = new URLSearchParams({
      query: query.slice(0, 200),
      per_page: String(
        Math.min(30, Math.max(1, Number(req.query.per_page) || 12))
      )
    });

    const response = await fetch(
      PEXELS_API + "/videos/search?" + params.toString(),
      {
        headers: { Authorization: apiKey },
        signal: AbortSignal.timeout(20000)
      }
    );

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      return res.status(502).json({
        success: false,
        error: "Pexels video search failed.",
        details: data.error || data.message || response.status
      });
    }

    res.json({
      success: true,
      total_results: data.total_results || 0,
      videos: data.videos || []
    });
  } catch (error) {
    res.status(502).json({
      success: false,
      error: getErrorMessage(error)
    });
  }
});

// Import external website HTML for use in the IDE.
app.post("/api/convert-site", async (req, res) => {
  try {
    const websiteUrl = String(req.body?.url || "").trim();

    if (!websiteUrl) {
      return res.status(400).json({
        success: false,
        error: "Provide a website URL."
      });
    }

    const result = await fetchExternalWebsite(websiteUrl);

    // Return source HTML; this route does not yet recreate
    // the website into separate editable project files.
    const titleMatch = result.html.match(
      /<title\b[^>]*>([\s\S]*?)<\/title>/i
    );

    const title = titleMatch
      ? titleMatch[1].replace(/<[^>]*>/g, "").trim()
      : "Imported Website";

    res.json({
      success: true,
      sourceUrl: result.url,
      title: title.slice(0, 300),
      html: result.html,
      message: "Website HTML imported successfully."
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      error: getErrorMessage(error)
    });
  }
});

console.log("A² Builder media and import routes loaded.");
 
/* =========================================
   BATCH 6 — FINAL SERVER SETUP
========================================= */


/* =========================================
   CLOUDFLARE PAGES — FREE WEBSITE DEPLOYMENT
   Uses credentials stored in Render Environment Variables.
========================================= */

const crypto = require("node:crypto");

const CLOUDFLARE_API_BASE = "https://api.cloudflare.com/client/v4";

function getCloudflareSettings() {
  const token =
    process.env.CLOUDFLARE_API_TOKEN ||
    process.env.CF_API_TOKEN ||
    process.env.CLOUDFLARE_TOKEN;

  const accountId =
    process.env.CLOUDFLARE_ACCOUNT_ID ||
    process.env.CF_ACCOUNT_ID;

  const defaultProject =
    process.env.CLOUDFLARE_PAGES_PROJECT ||
    process.env.CF_PAGES_PROJECT ||
    "";

  return { token, accountId, defaultProject };
}

function cleanPagesProjectName(value) {
  let name = String(value || "")
    .toLowerCase()
    .replace(/[^a-z0-9-]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .replace(/-+/g, "-")
    .slice(0, 28);

  if (!name) name = "a2-builder-site";
  if (!/^[a-z0-9]/.test(name)) name = "site-" + name;
  return name;
}

function getAssetContentType(filePath) {
  const extension = String(filePath).toLowerCase().split(".").pop();
  const types = {
    html: "text/html; charset=utf-8",
    htm: "text/html; charset=utf-8",
    css: "text/css; charset=utf-8",
    js: "application/javascript; charset=utf-8",
    mjs: "application/javascript; charset=utf-8",
    json: "application/json; charset=utf-8",
    txt: "text/plain; charset=utf-8",
    svg: "image/svg+xml",
    png: "image/png",
    jpg: "image/jpeg",
    jpeg: "image/jpeg",
    webp: "image/webp",
    gif: "image/gif",
    ico: "image/x-icon",
    woff: "font/woff",
    woff2: "font/woff2",
    map: "application/json",
    xml: "application/xml",
    pdf: "application/pdf"
  };
  return types[extension] || "application/octet-stream";
}

function normalizeDeploymentFiles(input) {
  let source = input;

  if (Array.isArray(input)) {
    source = {};
    for (const item of input) {
      if (item && typeof item.path === "string") {
        source[item.path] = item.content;
      }
    }
  }

  if (!source || typeof source !== "object" || Array.isArray(source)) {
    throw new Error("Provide files as an object like {\"index.html\":\"...\"} or an array of {path, content}.");
  }

  const entries = Object.entries(source);
  if (!entries.length) throw new Error("No project files were supplied.");
  if (entries.length > 1000) throw new Error("A maximum of 1,000 files can be deployed at once.");

  const files = {};
  let totalBytes = 0;

  for (const [rawPath, rawContent] of entries) {
    const filePath = String(rawPath || "").replace(/\\/g, "/").replace(/^\/+/, "");
    if (
      !filePath ||
      filePath.split("/").some(part => !part || part === "." || part === "..") ||
      filePath.startsWith(".git/") ||
      filePath.includes("\0")
    ) {
      throw new Error("Invalid project file path: " + rawPath);
    }

    if (typeof rawContent !== "string" && !Buffer.isBuffer(rawContent)) {
      throw new Error("File content must be text for: " + filePath);
    }

    const content = Buffer.isBuffer(rawContent) ? rawContent : Buffer.from(rawContent, "utf8");
    totalBytes += content.length;
    if (content.length > 25 * 1024 * 1024) {
      throw new Error("File exceeds Cloudflare's 25 MB file limit: " + filePath);
    }
    files[filePath] = content;
  }

  if (totalBytes > 20 * 1024 * 1024) {
    throw new Error("Total deployment content exceeds the 20 MB A² Builder limit.");
  }

  if (!Object.keys(files).some(name => name.toLowerCase() === "index.html")) {
    throw new Error("Your project must include an index.html file.");
  }

  return files;
}

async function cloudflareRequest(path, options = {}) {
  const { token } = getCloudflareSettings();
  const response = await fetch(CLOUDFLARE_API_BASE + path, {
    ...options,
    headers: {
      Authorization: "Bearer " + token,
      ...(options.headers || {})
    },
    signal: options.signal || AbortSignal.timeout(60000)
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok || data.success === false) {
    const detail = (data.errors || [])
      .map(item => item.message)
      .filter(Boolean)
      .join("; ");
    throw new Error(detail || data.message || ("Cloudflare API returned HTTP " + response.status));
  }
  return data;
}

async function ensureCloudflarePagesProject(accountId, projectName) {
  const basePath = "/accounts/" + encodeURIComponent(accountId) + "/pages/projects/" +
    encodeURIComponent(projectName);

  try {
    await cloudflareRequest(basePath, { method: "GET" });
    return;
  } catch (error) {
    // Only try creating the project when it does not already exist.
    if (!/404|not found|could not find|project/i.test(getErrorMessage(error))) {
      // Cloudflare's error wording varies; project creation is idempotently
      // attempted below, and an "already exists" response is handled there.
    }
  }

  try {
    await cloudflareRequest("/accounts/" + encodeURIComponent(accountId) + "/pages/projects", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: projectName,
        production_branch: "main",
        deployment_configs: {
          production: { compatibility_date: "2025-01-01" }
        }
      })
    });
  } catch (error) {
    // If it already exists, allow the deployment to continue.
    const message = getErrorMessage(error).toLowerCase();
    if (!message.includes("already exists") && !message.includes("already been taken") &&
        !message.includes("project name")) {
      throw error;
    }
  }
}

async function deployFilesToCloudflarePages(files, projectName) {
  const { token, accountId } = getCloudflareSettings();
  if (!token || !accountId) {
    throw new Error(
      "Cloudflare is not configured in Render. Add CLOUDFLARE_API_TOKEN and CLOUDFLARE_ACCOUNT_ID to Render Environment Variables."
    );
  }

  await ensureCloudflarePagesProject(accountId, projectName);

  const projectPath = "/accounts/" + encodeURIComponent(accountId) +
    "/pages/projects/" + encodeURIComponent(projectName);

  const tokenResult = await cloudflareRequest(projectPath + "/upload-token", {
    method: "GET"
  });
  const uploadJwt = tokenResult.result && tokenResult.result.jwt;
  if (!uploadJwt) throw new Error("Cloudflare did not return an asset upload token.");

  const assets = Object.entries(files).map(([filePath, content]) => {
    const hash = crypto.createHash("md5").update(content).digest("hex");
    return { filePath, content, hash, contentType: getAssetContentType(filePath) };
  });

  const missingResult = await (async () => {
    const response = await fetch(CLOUDFLARE_API_BASE + "/pages/assets/check-missing", {
      method: "POST",
      headers: {
        Authorization: "Bearer " + uploadJwt,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ hashes: assets.map(asset => asset.hash) }),
      signal: AbortSignal.timeout(60000)
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok || data.success === false) {
      throw new Error(
        (data.errors || []).map(item => item.message).filter(Boolean).join("; ") ||
        "Cloudflare could not check which files need uploading."
      );
    }
    return Array.isArray(data.result) ? data.result : [];
  })();

  const missingSet = new Set(missingResult);
  const missingAssets = assets.filter(asset => missingSet.has(asset.hash));

  // Cloudflare accepts a batch of base64-encoded asset values.
  for (let offset = 0; offset < missingAssets.length; offset += 20) {
    const batch = missingAssets.slice(offset, offset + 20).map(asset => ({
      key: asset.hash,
      value: asset.content.toString("base64"),
      base64: true,
      metadata: { contentType: asset.contentType }
    }));

    const response = await fetch(CLOUDFLARE_API_BASE + "/pages/assets/upload", {
      method: "POST",
      headers: {
        Authorization: "Bearer " + uploadJwt,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(batch),
      signal: AbortSignal.timeout(60000)
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok || data.success === false) {
      throw new Error(
        (data.errors || []).map(item => item.message).filter(Boolean).join("; ") ||
        "Cloudflare failed to upload project assets."
      );
    }
  }

  const manifest = {};
  for (const asset of assets) manifest[asset.filePath] = asset.hash;

  const form = new FormData();
  form.append("manifest", JSON.stringify(manifest));
  form.append("branch", "main");
  form.append("commit_dirty", "false");
  form.append("commit_message", "Deployed by A² Builder");

  const deployment = await cloudflareRequest(projectPath + "/deployments", {
    method: "POST",
    body: form
  });

  const result = deployment.result || {};
  const url = result.url ||
    (Array.isArray(result.aliases) && result.aliases[0]) ||
    (result.subdomain ? "https://" + result.subdomain + ".pages.dev" :
      "https://" + projectName + ".pages.dev");

  return {
    projectName,
    url,
    deploymentId: result.id || null,
    status: result.latest_stage?.status || "queued",
    filesDeployed: assets.length
  };
}

// Safe status endpoint: reports configuration without exposing secrets.
app.get("/api/deploy/status", (req, res) => {
  const config = getCloudflareSettings();
  res.json({
    success: true,
    provider: "Cloudflare Pages",
    configured: Boolean(config.token && config.accountId),
    projectConfigured: Boolean(config.defaultProject),
    endpoint: "/api/deploy"
  });
});

// Deploy generated website files to a free Cloudflare Pages subdomain.
// Expected JSON: { "projectName": "royal-styles", "files": { "index.html": "...", "style.css": "...", "script.js": "..." } }
app.post("/api/deploy", async (req, res) => {
  try {
    const body = req.body || {};
    const config = getCloudflareSettings();

    const suppliedName = body.projectName || body.project_name || body.name ||
      config.defaultProject || ("a2-site-" + Date.now().toString(36));
    const projectName = cleanPagesProjectName(suppliedName);
    const files = normalizeDeploymentFiles(body.files || body.projectFiles || body.project);

    const result = await deployFilesToCloudflarePages(files, projectName);
    res.status(200).json({
      success: true,
      message: "Website deployment request completed.",
      provider: "Cloudflare Pages",
      ...result
    });
  } catch (error) {
    console.error("Cloudflare Pages deployment failed:", getErrorMessage(error));
    res.status(502).json({
      success: false,
      error: getErrorMessage(error),
      provider: "Cloudflare Pages"
    });
  }
});

console.log("A² Builder Cloudflare Pages deployment routes loaded.");


// Handle unknown routes.
app.use((req, res) => {
  res.status(404).json({
    success: false,
    error: "Route not found.",
    path: req.path,
    method: req.method
  });
});

// Central error handler.
app.use((err, req, res, next) => {
  console.error("A² Builder server error:", err.message);

  if (res.headersSent) {
    return next(err);
  }

  res.status(err.status || 500).json({
    success: false,
    error: "An internal server error occurred."
  });
});

// Start the server only when this file runs directly.
if (require.main === module) {
  const server = app.listen(PORT, "0.0.0.0", () => {
    console.log("-------------------------------------");
    console.log("A² BUILDER BACKEND");
    console.log("-------------------------------------");
    console.log("Port:", PORT);
    console.log("Health: /api/health");
    console.log("AI: /api/ai");
    console.log("Generation: /api/generate");
    console.log("Providers: /api/providers");
    console.log("Media: /api/media/status");
    console.log("Website import: /api/convert-site");
    console.log("Configured AI providers:", getConfiguredProviders().length);
    console.log("-------------------------------------");
  });

  server.requestTimeout = 120000;
  server.headersTimeout = 125000;

  process.on("unhandledRejection", (reason) => {
    console.error(
      "Unhandled promise rejection:",
      getErrorMessage(reason)
    );
  });
}

module.exports = app;
